function execute() {
    return Response.success([
        { title: "Mới Cập Nhật", input: "https://xtruyen.vn/truyen/?m_orderby=latest", script: "gen.js" },
        { title: "Không Tiền", input: "https://xtruyen.vn/truyen/khong-co-tien-tu-cai-gi-tien/", script: "gen.js" },
        { title: "Truyện Full", input: "https://xtruyen.vn/danh-sach/truyen-full", script: "gen.js" }
    ]);
}