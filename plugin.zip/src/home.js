function execute() {
    return Response.success([
        { title: "Mới Cập Nhật", input: "https://xtruyen.vn/truyen/?m_orderby=latest", script: "gen.js" },
        { title: "Truyện Hot", input: "https://xtruyen.vn/truyen/?m_orderby=trending", script: "gen.js" },
        { title: "Top View", input: "https://xtruyen.vn/truyen/?m_orderby=views", script: "gen.js" },
        { title: "A-Z", input: "https://xtruyen.vn/truyen/?m_orderby=alphabet", script: "gen.js" },
        { title: "Số Chương", input: "https://xtruyen.vn/truyen/?m_orderby=chapter-number", script: "gen.js" }
    ]);
}