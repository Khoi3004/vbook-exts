function execute(url, page) {
    if (!page) page = '1';
    
    // Xử lý phân trang: Web này dùng tham số &page=X
    // Ví dụ: ?m_orderby=latest&page=2
    let link = url;
    if (url.includes("?")) {
        link += "&page=" + page;
    } else {
        link += "?page=" + page;
    }

    const response = fetch(link);
    if (response.ok) {
        const doc = response.html();
        const data = [];

        // Selector chuẩn dựa trên HTML ông gửi: .popular-item-wrap
        doc.select(".popular-item-wrap").forEach(e => {
            
            // Lấy tiêu đề và link
            let titleEl = e.select(".widget-title a");
            let linkTruyen = titleEl.attr("href");
            
            // Lấy ảnh bìa
            let imgEl = e.select(".popular-img img");
            let anhBia = imgEl.attr("src");
            
            // Lấy mô tả (Dùng tạm thông tin chương mới nhất và thể loại để hiển thị)
            let chapterInfo = e.select(".list-chapter").text().trim();
            // Xóa bớt khoảng trắng thừa và xuống dòng
            chapterInfo = chapterInfo.replace(/\s+/g, ' '); 

            if (titleEl.text()) {
                data.push({
                    name: titleEl.text(),
                    link: linkTruyen,
                    cover: anhBia,
                    host: "https://xtruyen.vn",
                    description: chapterInfo // Hiển thị: "Huyền Huyễn Tiên Hiệp ... Chương 318"
                });
            }
        });

        // Web này phân trang dạng số, cứ có dữ liệu là cộng page tiếp
        if (data.length > 0) {
            var next = parseInt(page) + 1;
            return Response.success(data, next.toString());
        }
    }
    return null;
}