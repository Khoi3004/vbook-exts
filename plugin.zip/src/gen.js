function execute(url, page) {
    if (!page) page = '1';
    
    // Xử lý phân trang cho xtruyen (thêm ?page=x)
    let link = url;
    if (url.includes("?")) {
        link += "&page=" + page;
    } else {
        link += "?page=" + page;
    }

    const response = fetch(link);
    if (response.ok) {
        const doc = response.html();
        const data = [];
        
        // Selector này tôi soi theo cấu trúc phổ biến của Xtruyen
        // Nó lấy các thẻ div chứa truyện trong danh sách
        doc.select(".row .col-xs-6").forEach(e => {
            data.push({
                name: e.select(".title-book a").text(),
                link: e.select(".title-book a").attr("href"),
                cover: e.select("img").attr("src"),
                host: "https://xtruyen.vn",
                description: e.select(".chapter-text").text()
            });
        });

        // Tính toán trang tiếp theo
        var next = parseInt(page) + 1;
        return Response.success(data, next.toString());
    }
    return null;
}