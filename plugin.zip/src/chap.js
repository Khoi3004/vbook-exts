function execute(url) {
    const response = fetch(url);
    if (response.ok) {
        const doc = response.html();
        doc.select("div[id^='ads']").remove(); // Xóa quảng cáo
        let content = doc.select("#chapter-c").html();
        content = content.replace(/<br\s*\/?>/gi, "\n");
        return Response.success(content);
    }
    return null;
}