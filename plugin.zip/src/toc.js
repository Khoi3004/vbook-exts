function execute(url) {
    // Sửa link giống detail
    if (url.slice(-1) === "/") url = url.slice(0, -1);
    if (!url.startsWith("http")) {
        url = "https://xtruyen.vn" + url;
    }

    const response = fetch(url);
    if (response.ok) {
        const doc = response.html();
        
        // Tìm danh sách chương: Thử tìm trong #list-chapter -> rồi thử .list-chapter
        // Lấy tất cả thẻ 'a' bên trong đó
        let el = doc.select("#list-chapter .row .col-xs-12 a, #list-chapter a, .list-chapter a");
        
        const data = [];
        el.forEach(e => {
            data.push({
                name: e.text(),
                url: e.attr("href"),
                host: "https://xtruyen.vn"
            });
        });
        return Response.success(data);
    }
    return null;
}