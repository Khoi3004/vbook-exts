function execute(url) {
    if (url.slice(-1) === "/") url = url.slice(0, -1);
    if (!url.startsWith("http")) url = "https://xtruyen.vn" + url;

    const response = fetch(url);
    if (response.ok) {
        const doc = response.html();
        const htmlContent = doc.html(); 
        
        // 1. Tìm ID truyện
        let storyId = "";
        // Thử nhiều kiểu tìm ID khác nhau để chắc ăn
        let idMatch = htmlContent.match(/story_id\s*=\s*(\d+)/) || 
                      htmlContent.match(/value="(\d+)" id="story_id"/) ||
                      htmlContent.match(/data-id="(\d+)"/);
        
        if (idMatch) storyId = idMatch[1];
                      
        if (storyId) {
            // 2. Gọi API
            let apiUrl = `https://xtruyen.vn/api/services/list-chapter?type=list_chapter&story_id=${storyId}`;
            let apiRes = fetch(apiUrl);
            
            if (apiRes.ok) {
                // --- XỬ LÝ JSON ---
                // API trả về JSON, cần chuyển thành object rồi mới lấy HTML
                let json = apiRes.json(); 
                let listHtml = "";
                
                // Kiểm tra xem HTML nằm ở đâu trong JSON (thường là .data hoặc .html)
                if (json.data) listHtml = json.data;
                else if (json.html) listHtml = json.html;
                else if (typeof json === "string") listHtml = json; // Trường hợp API trả về text thẳng
                
                // Parse lại đoạn HTML vừa bóc được
                // Lưu ý: Html.parse là hàm của vBook để tạo DOM từ chuỗi HTML
                let apiDoc = Html.parse(listHtml); 
                
                let elements = apiDoc.select("li a, a"); 
                const data = [];
                elements.forEach(e => {
                    let link = e.attr("href");
                    if (link && link.length > 5 && !link.startsWith("javascript")) {
                        if (!link.startsWith("http")) link = "https://xtruyen.vn" + link;
                        data.push({
                            name: e.text(),
                            url: link,
                            host: "https://xtruyen.vn"
                        });
                    }
                });
                
                if (data.length > 0) return Response.success(data);
            }
        } 
        
        // 3. Fallback: Nếu không lấy được qua API thì thử lấy trên trang gốc
        // (Dành cho truyện ngắn 1 trang không dùng API)
        let el = doc.select("#list-chapter a, .list-chapter a");
        if (el.length > 0) {
            const data = [];
            el.forEach(e => {
                let link = e.attr("href");
                if(link) {
                     if (!link.startsWith("http")) link = "https://xtruyen.vn" + link;
                     data.push({
                        name: e.text(),
                        url: link,
                        host: "https://xtruyen.vn"
                    });
                }
            });
            return Response.success(data);
        }
    }
    return null;
}