function execute(url) {
    if (url.slice(-1) === "/") url = url.slice(0, -1);
    if (!url.startsWith("http")) url = "https://xtruyen.vn" + url;

    const response = fetch(url);
    if (response.ok) {
        const htmlContent = response.text(); // Lấy source text
        
        // 1. Tìm ID truyện (Nâng cấp Regex)
        let storyId = "";
        // Bắt các trường hợp: story_id=123, story_id="123", var story_id = 123
        // Regex giải thích: Tìm chữ story_id, sau đó là dấu =, rồi có thể có dấu nháy, rồi đến số
        let match = htmlContent.match(/story_id\s*[:=]\s*["']?(\d+)["']?/i);
        
        if (match) {
            storyId = match[1];
        } else {
            // Dự phòng: Tìm id trong thẻ input hidden
            let inputMatch = htmlContent.match(/value=["']?(\d+)["']?\s+id=["']story_id["']/i);
            if (inputMatch) storyId = inputMatch[1];
        }

        // 2. Nếu có ID -> Gọi API
        if (storyId) {
            let apiUrl = `https://xtruyen.vn/api/services/list-chapter?type=list_chapter&story_id=${storyId}`;
            let apiRes = fetch(apiUrl);
            if (apiRes.ok) {
                let apiDoc = apiRes.html();
                let elements = apiDoc.select("li a, a"); 
                
                const data = [];
                elements.forEach(e => {
                    let link = e.attr("href");
                    if (link && link.length > 5 && !link.includes("javascript")) {
                        if (!link.startsWith("http")) link = "https://xtruyen.vn" + link;
                        data.push({
                            name: e.text(),
                            url: link,
                            host: "https://xtruyen.vn"
                        });
                    }
                });
                if (data.length > 0) return Response.success(data);
            }
        }
        
        // 3. Nếu vẫn lỗi -> Trả về danh sách rỗng (để không báo lỗi Error đỏ lòm)
        // Ít nhất app sẽ mở được vào trong, dù không có chương
        return Response.success([]);
    }
    return null;
}