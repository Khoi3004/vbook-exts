function execute(url) {
    const response = fetch(url);
    if (response.ok) {
        const doc = response.html();
        const el = doc.select("#list-chapter .row .col-xs-12 a");
        const data = [];
        el.forEach(e => {
            data.push({
                name: e.text(),
                url: e.attr("href"),
                host: "https://xtruyen.vn"
            });
        });
        return Response.success(data);
    }
    return null;
}