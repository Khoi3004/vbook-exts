function execute(url) {
    // Fix link
    if (url.slice(-1) === "/") url = url.slice(0, -1);
    if (!url.startsWith("http")) url = "https://xtruyen.vn" + url;

    const response = fetch(url);
    if (response.ok) {
        const html = response.text();
        
        // 1. Tìm ID truyện (Quan trọng!)
        // Tìm các biến kiểu: story_id = 12345; hoặc data-id="12345"
        let storyIdMatch = html.match(/story_id\s*=\s*(\d+)/i) || 
                           html.match(/data-id="(\d+)"/) || 
                           html.match(/value="(\d+)" id="story_id"/);
        
        if (storyIdMatch) {
            let storyId = storyIdMatch[1];
            
            // 2. Gọi API lấy danh sách chương
            // Đây là endpoint phổ biến cho dạng web này. Hy vọng nó trúng!
            let apiUrl = `https://xtruyen.vn/api/services/list-chapter?type=list_chapter&story_id=${storyId}`;
            
            const apiResponse = fetch(apiUrl);
            if (apiResponse.ok) {
                // API thường trả về HTML chứa danh sách thẻ <li> hoặc <option>
                let apiDoc = apiResponse.html();
                let el = apiDoc.select("li a, option"); // Quét tất cả thẻ a hoặc option
                
                const data = [];
                el.forEach(e => {
                    let link = e.attr("href") || e.attr("value");
                    let name = e.text();
                    
                    if (link && link !== "#") {
                         if (!link.startsWith("http")) link = "https://xtruyen.vn" + link;
                         data.push({
                            name: name,
                            url: link,
                            host: "https://xtruyen.vn"
                        });
                    }
                });
                return Response.success(data);
            }
        } else {
             // Nếu không tìm thấy ID, thử quét list cũ xem có ăn may không
             let doc = response.html();
             let el = doc.select("#list-chapter a, .list-chapter a");
             const data = [];
             el.forEach(e => data.push({
                name: e.text(),
                url: e.attr("href"),
                host: "https://xtruyen.vn"
             }));
             if(data.length > 0) return Response.success(data);
        }
    }
    return null;
}