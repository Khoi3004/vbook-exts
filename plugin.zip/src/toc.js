function execute(url) {
    // 1. Fix link
    if (url.slice(-1) === "/") url = url.slice(0, -1);
    if (!url.startsWith("http")) url = "https://xtruyen.vn" + url;

    const response = fetch(url);
    if (response.ok) {
        const doc = response.html();
        const html = response.text();

        // 2. Tìm ID truyện (Bắt buộc phải có để gọi API)
        let storyIdMatch = html.match(/story_id\s*=\s*(\d+)/) || 
                           html.match(/value="(\d+)" id="story_id"/);
        
        // Nếu không lấy được ID thì chịu chết, trả về null
        if (!storyIdMatch) return null;
        let storyId = storyIdMatch[1];

        const data = [];

        // 3. Tìm danh sách các nhóm chương (Ranges)
        // Tìm các thẻ li có thuộc tính data-value="1-to-99"
        let rangeElements = doc.select("li.has-child[data-value]");

        // TRƯỜNG HỢP 1: Truyện dài (Có chia nhóm)
        if (rangeElements.length > 0) {
            // Duyệt qua từng nhóm để tải dữ liệu
            rangeElements.forEach(e => {
                let val = e.attr("data-value"); // Lấy giá trị "1-to-99"

                // Gọi API lấy list chương của nhóm này
                let apiUrl = `https://xtruyen.vn/api/services/list-chapter?type=list_chapter&story_id=${storyId}&value=${val}`;
                
                let apiRes = fetch(apiUrl);
                if (apiRes.ok) {
                    // API trả về HTML chứa danh sách thẻ <a>
                    let chunkDoc = apiRes.html();
                    chunkDoc.select("a").forEach(chap => {
                         let link = chap.attr("href");
                         // Lọc bỏ link rác hoặc javascript:void(0)
                         if(link && link.length > 5 && !link.includes("javascript")) {
                             if (!link.startsWith("http")) link = "https://xtruyen.vn" + link;
                             data.push({
                                name: chap.text(),
                                url: link,
                                host: "https://xtruyen.vn"
                             });
                         }
                    });
                }
            });
        } 
        // TRƯỜNG HỢP 2: Truyện ngắn (Không chia nhóm, hiện thẳng luôn)
        else {
             let el = doc.select("#list-chapter .row .col-xs-12 a, .list-chapter a");
             el.forEach(e => {
                let link = e.attr("href");
                if(link) {
                    if (!link.startsWith("http")) link = "https://xtruyen.vn" + link;
                    data.push({
                        name: e.text(),
                        url: link,
                        host: "https://xtruyen.vn"
                    });
                }
             });
        }

        if (data.length > 0) return Response.success(data);
    }
    return null;
}