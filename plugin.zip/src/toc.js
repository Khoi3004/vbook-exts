function execute(url) {
    if (url.slice(-1) === "/") url = url.slice(0, -1);
    if (!url.startsWith("http")) url = "https://xtruyen.vn" + url;

    const response = fetch(url);
    if (response.ok) {
        const doc = response.html(); // Đọc 1 lần duy nhất
        const htmlContent = doc.html(); // Lấy text từ doc
        
        // 1. Tìm ID truyện
        let storyId = "";
        let idMatch = htmlContent.match(/story_id\s*=\s*(\d+)/) || 
                      htmlContent.match(/value="(\d+)" id="story_id"/);
                      
        if (idMatch) {
            storyId = idMatch[1];
            
            // 2. Gọi API lấy chương
            let apiUrl = `https://xtruyen.vn/api/services/list-chapter?type=list_chapter&story_id=${storyId}`;
            let apiRes = fetch(apiUrl);
            if (apiRes.ok) {
                let apiDoc = apiRes.html();
                let elements = apiDoc.select("li a, a"); 
                
                const data = [];
                elements.forEach(e => {
                    let link = e.attr("href");
                    if (link && link.length > 2 && !link.startsWith("javascript")) {
                        if (!link.startsWith("http")) link = "https://xtruyen.vn" + link;
                        data.push({
                            name: e.text(),
                            url: link,
                            host: "https://xtruyen.vn"
                        });
                    }
                });
                if (data.length > 0) return Response.success(data);
            }
        } 
        
        // 3. Dự phòng: Quét trực tiếp nếu API lỗi
        let el = doc.select("#list-chapter a, .list-chapter a");
        const data = [];
        el.forEach(e => {
            let link = e.attr("href");
            if(link) {
                 if (!link.startsWith("http")) link = "https://xtruyen.vn" + link;
                 data.push({
                    name: e.text(),
                    url: link,
                    host: "https://xtruyen.vn"
                });
            }
        });
        return Response.success(data);
    }
    return null;
}