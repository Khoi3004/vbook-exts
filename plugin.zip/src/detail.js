function execute(url) {
    const response = fetch(url);
    if (response.ok) {
        const doc = response.html();
        return Response.success({
            name: doc.select("h3.title").text(),
            cover: doc.select(".book-img img").attr("src"),
            author: doc.select(".info div:has(span:contains('Tác giả')) a").text() || "Đang cập nhật",
            description: doc.select(".desc-text").text(),
            detail: doc.select(".info").text(),
            host: "https://xtruyen.vn"
        });
    }
    return null;
}