function execute(url) {
    // Fix link
    if (url.slice(-1) === "/") url = url.slice(0, -1);
    if (!url.startsWith("http")) url = "https://xtruyen.vn" + url;

    const response = fetch(url);
    if (response.ok) {
        const doc = response.html();
        const html = response.text(); // Lấy source thô để quét Regex

        // 1. Lấy Tên: Tìm thẻ h3 hoặc title, nếu không có thì lấy đại thẻ a to nhất
        let name = doc.select("h3.title, h1.title-book, .title").text();
        if (!name) name = doc.select("title").text().replace(" - Xtruyen", "");

        // 2. Lấy Tác giả (Dùng Regex quét text thô)
        // Tìm chữ "Tác giả" rồi lấy đoạn text tiếp theo cho đến khi gặp chữ "Thể" hoặc xuống dòng
        let author = "Đang cập nhật";
        let authorMatch = html.match(/Tác giả\s*<[^>]+>\s*([^<]+)/i); 
        // Nếu regex trên trượt, thử regex đơn giản hơn
        if (!authorMatch) authorMatch = html.match(/Tác giả\s*[:|-]?\s*([^\n<]+)/i);
        if (authorMatch) author = authorMatch[1].trim();

        // 3. Lấy Mô tả
        // Tìm div chứa nội dung mô tả, thường là .desc-text hoặc id="story-detail"
        let description = doc.select(".desc-text, .story-detail-content, div[itemprop='description']").text();
        if (!description) description = "Chưa có mô tả (Web chống crawl)";

        // 4. Lấy Ảnh bìa
        let cover = doc.select(".book-img img, .img-cover img, img[itemprop='image']").attr("src");

        return Response.success({
            name: name,
            cover: cover,
            author: author,
            description: description,
            host: "https://xtruyen.vn"
        });
    }
    return null;
}