function execute(url) {
    if (url.slice(-1) === "/") url = url.slice(0, -1);
    if (!url.startsWith("http")) url = "https://xtruyen.vn" + url;

    const response = fetch(url);
    if (response.ok) {
        const doc = response.html(); // Đọc 1 lần duy nhất ra dạng DOM
        // Lấy chuỗi HTML từ DOM đã đọc (không gọi response.text nữa để tránh lỗi null)
        const htmlContent = doc.html(); 
        
        // 1. Lấy Tên (Xử lý xóa rác suffix)
        let name = doc.select("h3.title, h1.title-book, .title").text();
        if (!name) name = doc.select("title").text();
        // Xóa mấy đoạn thừa phía sau tên truyện
        if (name) {
            name = name.replace(/ - Xtruyen.*/i, "")
                       .replace(/ - Mới nhất.*/i, "")
                       .replace(/ - Đọc truyện.*/i, "")
                       .trim();
        }

        // 2. Lấy Tác giả (Quét trên chuỗi HTML từ DOM)
        let author = "Đang cập nhật";
        if (htmlContent) {
            // Thay thế thẻ <br> bằng xuống dòng để Regex dễ bắt
            let cleanHtml = htmlContent.replace(/<br\s*\/?>/gi, "\n");
            // Regex bắt chữ sau "Tác giả"
            let authorMatch = cleanHtml.match(/Tác giả\s*[:\n]+\s*([^\n<]+)/i);
            if (authorMatch) {
                author = authorMatch[1].trim();
            } else {
                // Dự phòng: Tìm thẻ meta
                let metaAuth = doc.select("meta[property='book:author']").attr("content");
                if (metaAuth) author = metaAuth;
            }
        }
        
        // 3. Lấy Mô tả
        let description = doc.select(".desc-text, .story-detail-content, div[itemprop='description']").text();
        if(description) description = description.replace("Giới thiệu", "").trim();

        // 4. Lấy Ảnh bìa
        let cover = doc.select(".book-img img, .img-cover img, img[itemprop='image']").attr("src");

        return Response.success({
            name: name || "Không tên",
            cover: cover || "",
            author: author,
            description: description || "Chưa có mô tả",
            host: "https://xtruyen.vn"
        });
    }
    return null;
}