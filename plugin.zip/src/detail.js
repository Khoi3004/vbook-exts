function execute(url) {
    if (url.slice(-1) === "/") url = url.slice(0, -1);
    if (!url.startsWith("http")) url = "https://xtruyen.vn" + url;

    const response = fetch(url);
    if (response.ok) {
        const doc = response.html();
        
        // 1. Lấy Tên Truyện (Xử lý triệt để tên rác)
        // Ưu tiên lấy trong thẻ h3 hoặc h1 chuẩn
        let name = doc.select("h3.title, h1.title, .title-book").text();
        
        // Nếu không có, lấy từ <title> nhưng cắt bỏ phần đuôi rác
        if (!name) {
            let pageTitle = doc.select("title").text();
            // Cắt tại dấu gạch ngang đầu tiên (Lấy phần trước dấu -)
            if (pageTitle.includes("-")) {
                name = pageTitle.split("-")[0].trim();
            } else {
                name = pageTitle;
            }
        }

        // 2. Lấy Tác giả (Thuật toán dò chữ)
        // Tìm thẻ chứa chữ "Tác giả"
        let author = doc.select(".info div:contains(Tác giả), .info p:contains(Tác giả)").text();
        if (author) {
            // Xóa chữ "Tác giả:" đi, chỉ lấy tên
            author = author.replace(/Tác giả\s*[:|-]?/i, "").trim();
        } else {
            // Dự phòng: Lấy từ meta tag
            author = doc.select("meta[property='book:author']").attr("content") || "Đang cập nhật";
        }

        // 3. Lấy Mô tả
        let description = doc.select(".desc-text, .story-detail-content").text();
        if (description) description = description.replace("Giới thiệu", "").trim();

        // 4. Lấy Ảnh bìa
        let cover = doc.select(".book-img img, .img-cover img").attr("src");

        return Response.success({
            name: name || "Không tên",
            cover: cover || "",
            author: author,
            description: description || "Chưa có mô tả",
            host: "https://xtruyen.vn"
        });
    }
    return null;
}