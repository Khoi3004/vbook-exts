function execute(url) {
    // 1. Tự động sửa link nếu thiếu domain (quan trọng!)
    if (url.slice(-1) === "/") url = url.slice(0, -1);
    if (!url.startsWith("http")) {
        url = "https://xtruyen.vn" + url;
    }

    const response = fetch(url);
    if (response.ok) {
        const doc = response.html();

        // 2. Vét cạn các trường hợp class phổ biến (Tránh lỗi null)
        
        // Lấy Tên truyện: Thử tìm h3.title -> nếu không có thì tìm h1 -> class .title
        let name = doc.select("h3.title, h1.title, .title-book, h1").first().text();

        // Lấy Ảnh bìa: Thử tìm trong .book-img -> nếu không có thì tìm thẻ img bất kỳ trong .info
        let cover = doc.select(".book-img img, .info-holder img, .col-image img").first().attr("src");
        
        // Lấy Tác giả: Tìm thẻ a nằm trong div chứa chữ "Tác giả"
        let author = doc.select(".info div:has(span:contains('Tác giả')) a, .author a, .info .item:contains(Tác giả)").text();

        // Lấy Mô tả: Thử các class mô tả phổ biến
        let description = doc.select(".desc-text, .description, #story-detail").text();

        // Lấy thông tin phụ (Trạng thái, Thể loại...)
        let detail = doc.select(".info, .list-info").text();

        // Trả về kết quả (Nếu thiếu thông tin nào thì điền tạm text mặc định để không bị lỗi)
        return Response.success({
            name: name || "Không tên",
            cover: cover || "",
            author: author || "Đang cập nhật",
            description: description || "Chưa có mô tả",
            detail: detail || "",
            host: "https://xtruyen.vn"
        });
    }
    return null;
}