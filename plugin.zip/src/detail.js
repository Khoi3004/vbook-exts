function execute(url) {
    // 1. Chuẩn hóa URL
    if (url.slice(-1) === "/") url = url.slice(0, -1);
    if (!url.startsWith("http")) url = "https://xtruyen.vn" + url;

    const response = fetch(url);
    if (response.ok) {
        const doc = response.html();
        const html = response.text(); // Lấy source thô

        // 2. Lấy Tên truyện (Thử nhiều kiểu thẻ)
        let name = doc.select("h3.title, h1.title-book, .title").text();
        if (!name) name = doc.select("title").text().replace(" - Xtruyen", "");

        // 3. Lấy Tác giả (Dùng Regex bắt xuống dòng)
        // Logic: Tìm chữ "Tác giả", bỏ qua các dấu xuống dòng, lấy dòng chữ tiếp theo
        let author = "Đang cập nhật";
        // Regex này nghĩa là: Tìm "Tác giả", sau đó là dấu xuống dòng (\r\n), rồi lấy nhóm ký tự tiếp theo
        let authorMatch = html.match(/Tác giả\s*[\r\n]+\s*([^\r\n]+)/i);
        if (authorMatch) {
            author = authorMatch[1].trim();
        } else {
            // Dự phòng: Tìm theo thẻ meta nếu có
            let metaAuthor = doc.select("meta[property='book:author']").attr("content");
            if (metaAuthor) author = metaAuthor;
        }

        // 4. Lấy Mô tả (Quét các class phổ biến của Xtruyen)
        let description = doc.select(".desc-text, .story-detail-content, div[itemprop='description']").text();
        // Xóa bớt mấy chữ thừa nếu có
        description = description.replace("Giới thiệu", "").trim();

        // 5. Lấy Ảnh bìa
        let cover = doc.select(".book-img img, .img-cover img, img[itemprop='image']").attr("src");

        return Response.success({
            name: name || "Không tên",
            cover: cover || "",
            author: author,
            description: description || "Chưa có mô tả",
            host: "https://xtruyen.vn"
        });
    }
    return null;
}