function execute(url) {
    if (url.slice(-1) === "/") url = url.slice(0, -1);
    if (!url.startsWith("http")) url = "https://xtruyen.vn" + url;

    const response = fetch(url);
    if (response.ok) {
        const doc = response.html();
        
        // 1. Lấy Tên: Xóa các hậu tố rác
        let name = doc.select("h3.title, h1.title-book, .title").text();
        if (!name) name = doc.select("title").text();
        if (name) {
            name = name.replace(/ - Xtruyen.*/i, "")
                       .replace(/ - Mới nhất.*/i, "")
                       .trim();
        }

        // 2. Lấy Tác giả (Chiêu mới: Tìm link chứa từ khóa 'tacgia')
        let author = doc.select("a[href*='/tacgia/']").text();
        if (!author) {
            // Dự phòng: Tìm thẻ người đăng nếu không có tác giả
            author = doc.select(".info a[href*='/thanh-vien/']").text();
        }
        if (!author) author = "Đang cập nhật";

        // 3. Lấy Mô tả
        let description = doc.select(".desc-text, .story-detail-content").text();
        if(description) description = description.replace("Giới thiệu", "").trim();

        // 4. Lấy Ảnh bìa
        let cover = doc.select(".book-img img, .img-cover img").attr("src");

        return Response.success({
            name: name,
            cover: cover,
            author: author,
            description: description || "Chưa có mô tả",
            host: "https://xtruyen.vn"
        });
    }
    return null;
}