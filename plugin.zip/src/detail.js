function execute(url) {
    // Tự động sửa link
    if (url.slice(-1) === "/") url = url.slice(0, -1);
    if (!url.startsWith("http")) {
        url = "https://xtruyen.vn" + url;
    }

    const response = fetch(url);
    if (response.ok) {
        const html = response.text(); // Lấy toàn bộ source HTML thô
        
        // --- THUẬT TOÁN DEBUG ---
        // Tìm xem đoạn chứa chữ "Tác giả" nó nằm trong thẻ nào
        let debugStr = "=== MÃ HTML GỐC (CHỤP MÀN HÌNH GỬI TÔI) ===\n";
        
        // Cắt lấy 1 đoạn HTML xung quanh chữ "Tác giả" để xem class
        let idx = html.indexOf("Tác giả");
        if (idx > -1) {
            debugStr += html.substring(idx - 300, idx + 300);
        } else {
            // Nếu không thấy chữ Tác giả, lấy 1000 ký tự đầu tiên của body
            let bodyIdx = html.indexOf("<body");
            if (bodyIdx > -1) debugStr += html.substring(bodyIdx, bodyIdx + 800);
            else debugStr += html.substring(0, 800);
        }

        // Cắt thêm 1 đoạn tìm class chứa danh sách chương
        debugStr += "\n\n=== SOi LIST CHƯƠNG ===\n";
        let chapIdx = html.indexOf("list-chapter"); // Thử tìm class list-chapter
        if (chapIdx > -1) {
             debugStr += html.substring(chapIdx - 100, chapIdx + 300);
        } else {
             // Nếu không thấy, tìm chữ "Chương 1"
             let c1Idx = html.indexOf("Chương 1");
             if (c1Idx > -1) debugStr += html.substring(c1Idx - 200, c1Idx + 200);
        }

        // Trả về kết quả hiển thị lên màn hình
        return Response.success({
            name: "CHẾ ĐỘ DEBUG - CHỤP MÀN HÌNH NÀY",
            cover: "",
            author: "Debug Mode",
            description: debugStr, // Mã HTML sẽ hiện ở đây
            host: "https://xtruyen.vn"
        });
    }
    return null;
}