const baseUrl = "https://xtruyen.vn";

// Hàm lấy thông tin truyện
function detail(url) {
    const response = fetch(url);
    if (response.ok) {
        const doc = response.html();
        return {
            title: doc.select("h3.title").text(),
            cover: doc.select(".book-img img").attr("src"),
            author: doc.select(".info div:has(span:contains('Tác giả')) a").text() || "Đang cập nhật",
            description: doc.select(".desc-text").text(),
            detail: doc.select(".info").text(), // Thông tin phụ (tình trạng, thể loại...)
            host: baseUrl
        };
    }
    return null;
}

// Hàm lấy danh sách chương (Mục lục)
function toc(url) {
    const response = fetch(url);
    if (response.ok) {
        const doc = response.html();
        const el = doc.select("#list-chapter .row .col-xs-12 a"); // Chọn thẻ a chứa link chương
        const data = [];
        
        // Duyệt qua từng thẻ a để lấy tên và link
        el.forEach(e => {
            data.push({
                name: e.text(),
                url: e.attr("href"),
                host: baseUrl
            });
        });
        
        return data;
    }
    return null;
}

// Hàm lấy nội dung chương
function chap(url) {
    const response = fetch(url);
    if (response.ok) {
        const doc = response.html();
        
        // Xóa các thành phần rác/quảng cáo nếu có (ví dụ div quảng cáo)
        doc.select("div[id^='ads']").remove(); 
        
        // Lấy nội dung chính
        let content = doc.select("#chapter-c").html();
        
        // Xử lý xuống dòng cho đẹp (thay thế thẻ br bằng xuống dòng)
        content = content.replace(/<br\s*\/?>/gi, "\n");
        
        return content;
    }
    return null;
}